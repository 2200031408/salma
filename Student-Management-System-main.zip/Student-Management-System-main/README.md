# Student-Management-System
The project has been designed using Python and MySQL to manage and access the records of students in educational establishments. It can store and retrieve student information, and track student attendance, schedules, grades, etc. The main goal is to improve overall efficiency, accuracy, and communication within the educational institution.
